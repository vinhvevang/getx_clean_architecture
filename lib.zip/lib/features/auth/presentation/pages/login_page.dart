import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:getx_clean_archi/core/constant/app_images.dart';
import 'package:getx_clean_archi/core/widgets/login_text_field.dart';
import '../controllers/login_controller.dart';

class LoginPage extends GetView<LoginController> {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Stack(
            children: [
              /// LOGO
              Positioned(
                top: 0,
                right: 100,
                child: SizedBox(
                  width: 300,
                  child: SvgPicture.asset(
                    AppImages.biglogo,
                    fit: BoxFit.contain,
                  ),
                ),
              ),

              /// FORM
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.only(top: 81),
                  child: Form(
                    key: controller.formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          LoginTextField(
                            controller: controller.tax,
                            label: "Mã số thuế",
                            focusNode: controller.taxFocus,
                            nextFocus: controller.userFocus,
                          ),

                          const SizedBox(height: 20),

                          LoginTextField(
                            controller: controller.username,
                            label: "Tên đăng nhập",
                            focusNode: controller.userFocus,
                            nextFocus: controller.passFocus,
                          ),

                          const SizedBox(height: 20),

                          LoginTextField(
                            controller: controller.password,
                            label: "Mật khẩu",
                            focusNode: controller.passFocus,
                            isPassword: true,
                          ),

                          const SizedBox(height: 24),

                          Obx(
                            () => SizedBox(
                              width: double.infinity,
                              height: 55,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFFF24E1E),
                                ),
                                onPressed:
                                    controller.isLoading.value
                                        ? null
                                        : controller.submit,
                                child:
                                    controller.isLoading.value
                                        ? const CircularProgressIndicator(
                                          color: Colors.white,
                                        )
                                        : const Text(
                                          'Đăng nhập',
                                          style: TextStyle(color: Colors.white),
                                        ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 200),

                          /// FOOTER
                          Row(
                            children: [
                              /// ITEM 1
                              Container(
                                height: 75,
                                width: 100,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey[300]!),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: 25,
                                      width: 25,
                                      child: SvgPicture.asset(
                                        AppImages.headphones,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                    const SizedBox(width: 5),
                                    const Text(
                                      "Trợ giúp",
                                      style: TextStyle(fontSize: 15),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(width: 15),

                              /// ITEM 2
                              Container(
                                height: 75,
                                width: 100,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey[300]!),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: 25,
                                      width: 25,
                                      child: SvgPicture.asset(
                                        AppImages.sociallinnk,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                    const SizedBox(width: 5),
                                    const Text(
                                      "Contact",
                                      style: TextStyle(fontSize: 15),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(width: 15),

                              /// ITEM 3
                              Container(
                                height: 75,
                                width: 100,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey[300]!),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: 25,
                                      width: 25,
                                      child: SvgPicture.asset(
                                        AppImages.searchnormal,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                    const SizedBox(width: 5),
                                    const Text(
                                      "Tra cứu",
                                      style: TextStyle(fontSize: 15),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FooterItem extends StatelessWidget {
  final String title;

  const _FooterItem(this.title);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 75,
      width: 100,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(title),
    );
  }
}
