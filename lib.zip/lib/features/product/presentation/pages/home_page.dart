import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_clean_archi/core/widgets/card_product.dart';
import 'package:getx_clean_archi/features/product/domain/entities/product.dart';
import 'package:getx_clean_archi/features/product/presentation/controllers/home_controller.dart';

class HomePage extends GetView<HomeController> {
  HomePage({super.key});

  void _showFilterDialog() {
    Get.dialog(
      AlertDialog(
        title: const Text('Lọc theo giá'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: controller.mincontroller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(label: Text('Giá tối thiểu')),
            ),
            TextFormField(
              controller: controller.maxcontroller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(label: Text('Giá tối đa')),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              controller.filter();
              Get.back();
            },
            child: const Text('Xóa lọc'),
          ),
          TextButton(onPressed: controller.apply, child: const Text('Áp dụng')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // ── Thanh tìm kiếm + nút lọc ──
          SafeArea(
            child: Container(
              height: 56,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: controller.findName,
                      onChanged: controller.find,
                      decoration: const InputDecoration(
                        label: Text('Nhap ten sp ...'),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: _showFilterDialog,
                    icon: const Icon(Icons.filter_list),
                    tooltip: 'Lọc theo giá',
                  ),
                ],
              ),
            ),
          ),

          // ── Grid sản phẩm ──
          Expanded(
            child: Scaffold(
              body: Obx(
                () => GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    childAspectRatio: 0.8,
                    crossAxisSpacing: 3,
                    crossAxisCount: 2,
                  ),
                  itemCount: controller.filteredProducts.length,
                  itemBuilder: (context, i) {
                    final actualIndex = controller.products.indexOf(
                      controller.filteredProducts[i],
                    );

                    return CardProduct(
                      name: controller.filteredProducts[i].name,
                      price: controller.filteredProducts[i].price,
                      quantity: controller.filteredProducts[i].quan,
                      onDelete:()=> controller.remove(i),
                      onEdit: (){
                        Product p = Product(controller.filteredProducts[i].name,
                         controller.filteredProducts[i].price, 
                         controller.filteredProducts[i].quan
                         );
                        controller.edit(p, i);
                        },
                    );
                  },
                ),
              ),

              // FAB thêm sản phẩm
              floatingActionButton: FloatingActionButton(
                onPressed: () {
                  Get.dialog(
                    AlertDialog(
                      title: const Text('nhap thong tin san pham'),
                      actions: [
                        TextFormField(
                          controller: controller.name,
                          decoration: const InputDecoration(
                            label: Text('Ten san pham'),
                          ),
                        ),
                        TextFormField(
                          controller: controller.price,
                          decoration: const InputDecoration(label: Text('gia')),
                        ),
                        TextFormField(
                          controller: controller.quan,
                          decoration: const InputDecoration(
                            label: Text('so luong'),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            controller.add(
                              Product(
                                controller.name.text,
                                double.tryParse(controller.price.text) ?? 0,
                                double.tryParse(controller.quan.text) ?? 0,
                              ),
                            );
                            Get.back();
                          },
                          child: const Text('them'),
                        ),
                      ],
                    ),
                  );
                },
                child: const Icon(Icons.add),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
