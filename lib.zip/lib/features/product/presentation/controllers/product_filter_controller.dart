import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_clean_archi/core/constant/category.dart';

/// Kết quả trả về khi đóng dialog lọc: hoặc người dùng bấm "Xóa" (reset toàn
/// bộ, kể cả từ khóa tìm kiếm) hoặc bấm "Áp dụng" với các giá trị đã chọn.
class ProductFilterResult {
final bool cleared;
final Category category;
final double? minPrice;
final double? maxPrice;

ProductFilterResult.applied({
required this.category,
required this.minPrice,
required this.maxPrice,
}) : cleared = false;

ProductFilterResult.cleared()
: cleared = true,
category = Category.all,
minPrice = null,
maxPrice = null;
}

class ProductFilterController extends GetxController {
ProductFilterController({
required Category initialCategory,
double? initialMinPrice,
double? initialMaxPrice,
}) : selectedCategory = initialCategory.obs {
if (initialMinPrice != null) {
minPriceController.text = _formatNumberForInput(initialMinPrice);
}
if (initialMaxPrice != null) {
maxPriceController.text = _formatNumberForInput(initialMaxPrice);
}
}

final formKey = GlobalKey<FormState>();

final Rx<Category> selectedCategory;
final hasAttemptedSubmit = false.obs;

final minPriceController = TextEditingController();
final maxPriceController = TextEditingController();

/// ✅ FocusNode đặt đúng chỗ
final minPriceFocus = FocusNode();
final maxPriceFocus = FocusNode();

void selectCategory(Category category) => selectedCategory.value = category;

void onFieldChanged() {
if (hasAttemptedSubmit.value) {
formKey.currentState?.validate();
}
}

String? validatePriceField(String? value) {
final trimmed = (value ?? '').trim();
if (trimmed.isEmpty) return null;
if (double.tryParse(trimmed) == null) return 'Giá không hợp lệ';

final min = double.tryParse(minPriceController.text.trim());
final max = double.tryParse(maxPriceController.text.trim());

if (min != null && max != null && min > max) {
  return 'Giá từ phải ≤ giá đến';
}

return null;

}

ProductFilterResult? apply() {
hasAttemptedSubmit.value = true;

if (!formKey.currentState!.validate()) return null;

return ProductFilterResult.applied(
  category: selectedCategory.value,
  minPrice: double.tryParse(minPriceController.text.trim()),
  maxPrice: double.tryParse(maxPriceController.text.trim()),
);

}

ProductFilterResult clear() => ProductFilterResult.cleared();

String _formatNumberForInput(double value) {
return value == value.roundToDouble()
? value.toInt().toString()
: value.toString();
}

/// ❌ KHÔNG cần dispose thủ công nữa
/// vì bạn đang dùng controller tạm trong dialog

@override
void onClose() {
minPriceController.dispose();
maxPriceController.dispose();
minPriceFocus.dispose();
maxPriceFocus.dispose();
super.onClose();
}
}
