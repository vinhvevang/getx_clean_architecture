
import 'package:getx_clean_archi/features/product/domain/entities/product.dart';
import 'package:getx_clean_archi/features/product/domain/repository/product_repository.dart';

class FilterProduct {
  final ProductRepository repository;

  FilterProduct(this.repository);

  List<Product> call({int? minPrice, int? maxPrice,String? keyword}) {
    return repository.getProducts().where((p) {
      final matchesMin = minPrice == null || p.price >= minPrice;
      final matchesMax = maxPrice == null || p.price <= maxPrice;
      return matchesMin && matchesMax;
    }).toList();
  }
}
