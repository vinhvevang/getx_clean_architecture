import 'package:flutter/material.dart';

class CardProduct extends StatelessWidget {
  final String name;
  final double price;
  final double quantity;
  final VoidCallback onDelete;
  final VoidCallback onEdit;

  const CardProduct({
    super.key,
    required this.name,
    required this.price,
    required this.quantity,
    required this.onDelete,
    required this.onEdit
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            /// Icon sản phẩm (placeholder)
            Container(
              width: 45,
              height: 100,
              decoration: BoxDecoration(
                color: Colors.blue.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.shopping_bag),
            ),

            const SizedBox(width: 16),

            /// Thông tin sản phẩm
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                   "Tên sản phẩm : "+ name,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Text(
                    "Giá: ${price} đ",
                    style: const TextStyle(color: Colors.green),
                  ),

                  const SizedBox(height: 4),

                  Text(
                    "Số lượng: $quantity",
                    style: const TextStyle(color: Colors.grey),
                  ),

                  Row(
                    children: [
                      IconButton(onPressed: onDelete, icon: Icon(Icons.delete)),
                      IconButton(onPressed: onEdit, icon: Icon(Icons.edit)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}