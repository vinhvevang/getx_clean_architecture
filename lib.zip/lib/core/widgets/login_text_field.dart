import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_clean_archi/core/widgets/app_text_field.dart';
import 'package:getx_clean_archi/features/auth/presentation/controllers/login_controller.dart';


class LoginTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final FocusNode focusNode;
  final FocusNode? nextFocus;
  final bool isPassword;

  const LoginTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.focusNode,
    this.nextFocus,
    this.isPassword = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = Get.find<LoginController>();

    return Obx(() => AppTextFormField(
          controller: controller,
          label: label,
          isSubmitted: c.isSubmitted.value,
          focusNode: focusNode,
          obscureText: isPassword ? c.isOScured.value : false,

          onChanged: (_) => c.onChanged(),

          textInputAction:
              nextFocus != null ? TextInputAction.next : TextInputAction.done,

          onEditingComplete: () {
            if (nextFocus != null) {
              FocusScope.of(context).requestFocus(nextFocus);
            } else {
              FocusScope.of(context).unfocus();
              c.submit();
            }
          },

          suffixIcon: isPassword
              ? IconButton(
                  onPressed: c.checkVisibility,
                  icon: Icon(
                    c.isOScured.value
                        ? Icons.visibility_off
                        : Icons.visibility,
                  ),
                )
              : null,
        ));
  }
}